<?php 
  session_start();



 if (($_SESSION['Login']=="OK")) {
     echo   "Login realizado com suceso111!!";
     exit;
    }



if($_POST['nome']=='abc'  AND $_POST['senha']=='123'){
	echo   "Login realizado com suceso!!";
	$_SESSION['Login']="OK";
}else{
    header('Location: index.php?error=1');
}
?>