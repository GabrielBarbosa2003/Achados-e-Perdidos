<?php 
  session_start();


	if(isset($_SESSION['Login'])){
 if (($_SESSION['Login']=="OK")) {
     echo   "Login realizado com suceso!!";
     	echo "<a href = 'i_sair.php'><br>sair </a>";

     //exit;
    }
}


if($_POST['usuario']=='abc' AND $_POST['senha']=='123'){
	echo   "Login realizado com suceso!!";
	$_SESSION['Login']="OK";
	echo "<a href = 'i_sair.php'><br>sair </a>";
}else{
    header('Location: index.php?error=1');
}

$db = mysqli_connect('localhost:3307','root','','db_login');
if(!$db){
echo "<br>Não deu para conectar ao Banco de Dados";
exit;
}else{
echo "<br>Conexão com Sucesso !!</br>";
}

$query = "select * from tb_login where usuario like '".$_POST['usuario']."'";

$result=mysqli_query($db,$query);

$row = mysqli_fetch_array($result,MYSQLI_BOTH);
			 echo '<br />codigo: ';
			 echo stripslashes($row[0]);


?>