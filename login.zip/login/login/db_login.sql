create database db_login;

use db_login;

create table tb_login(
codigo int primary key auto_increment,
usuario varchar(20),
senha varchar(200)
);

insert into tb_login(codigo,usuario,senha) values('1','abc','123');

select*from  tb_login;