
  <?php 
  session_start();

  //session_destroy();

    if (isset($_SESSION['Login'])=='OK') {
      header("Location:acesso.php");
    }
  ?>
<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title></title>
    <link rel="stylesheet" href="style.css">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.4.1/jquery.min.js" charset="utf-8"></script>
  </head>
  <body>
    <form action="acesso.php" class="login-form" method="POST">
      <h1>Acesso</h1>
        
      <div class="txtb">
        <input type="text" name="nome">
        <span data-placeholder="Usuario"></span>
      </div>

      <div class="txtb">
        <input type="password" name="senha">
        <span data-placeholder="Senha"></span>
      </div>
    <?php 

      if(isset($_GET['error'])){
        echo "<span style='color:red'>Usuario ou Senha Invalidos!</span>";
      }
    ?>

    <input type="submit" class="logbtn" value="Logar" name="logar">

    <div class="bottom-text">
      Não Tem Conta? <a href="#">Cadastrar</a>
    </div>

    </form>
  </body>
</html>
