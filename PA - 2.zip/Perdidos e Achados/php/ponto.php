<!DOCTYPE html>
  <head>
    <title>Ponto</title>
    <?php
      require_once "i_topo.php";
      ?>
  <center>
    <h1>Ponto de Achado e Perdido no IFSP Campinas: </h1>
    <img src="../imagens/ponto.png" width="37%" height="20%">
  </center>    
  </body>
</html>