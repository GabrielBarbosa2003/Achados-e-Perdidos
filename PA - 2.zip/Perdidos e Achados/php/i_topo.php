<meta charset="utf-8">
	<link rel="stylesheet" type="text/css" href="../css/estilo.css"/>
  </head>
  <body>
	<div class="container">
	<center><img src="../imagens/titulo.png"></center>
	</div>
  <div class="menu">
      <a href="home.php">Página Inicial &nbsp&nbsp</a>
      <a href="ponto.php">Ponto de Achados e Perdidos &nbsp&nbsp</a>
      <a href="perdi.php">Perdi um Objeto! &nbsp&nbsp</a>
      <a href="controle.php">Objetos Encontrados</a>
  </div>