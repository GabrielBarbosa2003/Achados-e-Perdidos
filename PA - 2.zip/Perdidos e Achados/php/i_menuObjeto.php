<LINK rel="stylesheet" HREF="../css/estiloitem.css" type="text/css"/>
<DIV id="BARRALATERAL">
			<UL>
				<LI> <a href= "form_cadastra.php">Cadastrar</a> </LI>
				<LI> <a href= "form_pesquisa1.php">Pesquisar</a> </LI>
				<LI> <a href= "form_exclui.php">Apagar</a> </LI>
				<LI> <a href= "form_altera.php">Modificar</a> </LI>
			</UL>
		</DIV>

	</HEAD>
		<body>
			