<!DOCTYPE html>
  <head>
    <title>PA - Início</title>
   <?php
      require_once "i_topo.php";
      ?>
    <div id="secundaria">
        <h1><u>Sobre o sistema: </u></h1>
        <p> &nbsp &nbsp &nbsp &nbsp O presente sistema de achados e perdidos foi desenvolvido pelos alunos Rafael Almeida, Gabriel Cabral e Gabriel Carvalho do Instituto Federal de Ciência, Educação e Tecnologia de São Paulo - Campus Campinas, ingressos no 2º ano do Curso técnico de informática integrado ao Ensino Médio com o auxílio de professores formados na área de informática. Tem como intuito ajudar pessoas que tiverem algum objeto que foi perdido a ajudar a encontrá-lo. De início  o sistema servirá apenas para objetos perdidos dentro do IFSP Campinas, caso dê muito certo, expandiremos este sistema para outros lugares.</p>
    </div>
    <div id="terciaria">
        <br>
        <img src="../imagens/cti.jpg" width="600px">
    </div>
      
  </body>
</html>