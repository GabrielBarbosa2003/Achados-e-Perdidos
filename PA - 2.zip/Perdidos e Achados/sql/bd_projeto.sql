Drop database if exists bd_projeto;
create database bd_projeto;
use bd_projeto;
create table tb_objeto(
  cod_obj int primary key auto_increment,
  desc_obj varchar(100) not null,
  cor_obj varchar(30),
  marca_obj varchar(30),
  local_enc varchar(50),
  data_enc date
  );

select *from tb_objeto;